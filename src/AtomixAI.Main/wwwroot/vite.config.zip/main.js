import { Editor } from '@tiptap/core'
import StarterKit from '@tiptap/starter-kit'
import Mention from '@tiptap/extension-mention'
import tippy from 'tippy.js'

// Глобальное состояние
window.revitMenuItems = [];
let currentPopup = null;
let currentSelectedIndex = 0;
let lastMentionProps = null;

/**
 * 1. УПРАВЛЕНИЕ МЕНЮ (МЫШЬ + КЛАВИАТУРА)
 */
window.onMenuItemClick = (index) => {
    const item = window.revitMenuItems[index];
    if (!item) return;

    if (item.hasChildren) {
        fetchChildren(item);
    } else {
        if (lastMentionProps && lastMentionProps.command) {
            // Вставляем тег через команду Tiptap
            lastMentionProps.command({ id: item.id, label: item.label });
            // Принудительно возвращаем фокус в редактор
            setTimeout(() => window.editor.commands.focus(), 10);
        }
    }
};

window.onMenuItemHover = (index) => {
    if (currentSelectedIndex !== index) {
        currentSelectedIndex = index;
        updatePopupContent();
    }
};

function updatePopupContent() {
    if (currentPopup && currentPopup.setContent) {
        currentPopup.setContent(renderMenuHtml());
    }
}

function fetchChildren(item) {
    window.revitMenuItems = [{ label: "Загрузка из Revit...", id: "loading", hasChildren: false }];
    updatePopupContent();
    currentSelectedIndex = 0;
    
    window.chrome?.webview?.postMessage({ 
        action: 'GET_CHILDREN', 
        id: item.id, 
        group: item.group 
    });
}

/**
 * 2. ГЕНЕРАЦИЯ HTML (С защитой от потери фокуса)
 */
function renderMenuHtml() {
    if (!window.revitMenuItems || window.revitMenuItems.length === 0) {
        return '<div style="padding:10px; color:#aaa; background:#222; border-radius:4px; font-size:13px; border:1px solid #444;">Поиск в Revit...</div>';
    }

    return `
        <div class="revit-menu-list" 
             onmousedown="event.preventDefault()" 
             style="min-width:220px; background:#222; color:#eee; border:1px solid #444; border-radius:6px; padding:4px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); font-family: 'Segoe UI', Tahoma, sans-serif;">
            ${window.revitMenuItems.map((item, index) => `
                <div class="menu-item" 
                     onclick="window.onMenuItemClick(${index})"
                     onmouseenter="window.onMenuItemHover(${index})"
                     onmousedown="event.preventDefault(); event.stopPropagation();"
                     style="
                        padding:7px 10px; 
                        cursor:pointer; 
                        display:flex; 
                        justify-content:space-between;
                        align-items:center;
                        border-radius:4px;
                        margin-bottom: 1px;
                        font-size: 13px;
                        transition: background 0.1s;
                        background:${index === currentSelectedIndex ? '#0078d4' : 'transparent'};
                        color:${index === currentSelectedIndex ? '#fff' : '#ccc'};
                ">
                    <span style="pointer-events:none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.label}</span>
                    ${item.hasChildren ? '<span style="opacity:0.5; font-size:10px; pointer-events:none; margin-left:10px;">▶</span>' : ''}
                </div>
            `).join('')}
        </div>
    `;
}

/**
 * 3. ИНИЦИАЛИЗАЦИЯ TIPTAP
 */
const editor = new Editor({
    element: document.querySelector('#userInput'),
    extensions: [
        StarterKit,
        Mention.configure({
            HTMLAttributes: { class: 'revit-tag' },
            suggestion: {
                char: '#',
                render: () => {
                    return {
                        onStart: (props) => {
                            lastMentionProps = props;
                            currentSelectedIndex = 0;
                            window.revitMenuItems = [];
                            
                            // Запрос в C#
                            window.chrome?.webview?.postMessage({ action: 'GET_ROOT_MENU' });

                            // Создание Tippy (Исправлено: берем [0] элемент)
                            const tippyInstances = tippy(document.body, {
                                getReferenceClientRect: props.clientRect,
                                appendTo: () => document.body,
                                content: renderMenuHtml(),
                                showOnCreate: true,
                                interactive: true,
                                trigger: 'manual',
                                placement: 'bottom-start',
                                allowHTML: true,
                                animation: false,
                                onHidden: (instance) => instance.destroy(), // Чистим память
                            });
                            currentPopup = tippyInstances[0]; 
                        },

                        onUpdate: (props) => {
                            lastMentionProps = props;
                            if (currentPopup) {
                                currentPopup.setProps({ getReferenceClientRect: props.clientRect });
                                updatePopupContent();
                            }
                        },

                        onKeyDown: (props) => {
                            if (!currentPopup) return false;
                            const { event } = props;

                            if (event.key === 'Escape') { 
                                currentPopup.hide(); 
                                return true; 
                            }
                            
                            if (event.key === 'ArrowUp') {
                                currentSelectedIndex = (currentSelectedIndex + window.revitMenuItems.length - 1) % window.revitMenuItems.length;
                                updatePopupContent();
                                return true;
                            }
                            if (event.key === 'ArrowDown') {
                                currentSelectedIndex = (currentSelectedIndex + 1) % window.revitMenuItems.length;
                                updatePopupContent();
                                return true;
                            }
                            
                            if (event.key === 'ArrowRight' || event.key === 'Enter') {
                                const item = window.revitMenuItems[currentSelectedIndex];
                                if (item) {
                                    if (item.hasChildren) {
                                        fetchChildren(item);
                                    } else if (event.key === 'Enter') {
                                        props.command({ id: item.id, label: item.label });
                                    }
                                }
                                return true;
                            }
                            return false;
                        },

                        onExit: () => {
                            if (currentPopup) {
                                currentPopup.hide();
                                currentPopup.destroy();
                                currentPopup = null;
                            }
                            lastMentionProps = null;
                        },
                    }
                }
            }
        })
    ],
    content: '',
});

/**
 * 4. ОБРАБОТКА СООБЩЕНИЙ ИЗ REVIT (C#)
 */
window.chrome?.webview?.addEventListener('message', (event) => {
    const data = event.data;
    
    // Если C# прислал новые пункты меню
    if (data.type === 'SET_MENU_ITEMS') {
        window.revitMenuItems = data.payload || [];
        updatePopupContent();
    }
    
    // Если нужно программно закрыть всё
    if (data.action === 'CLOSE_MENU') {
        currentPopup?.hide();
    }
});

window.editor = editor;
