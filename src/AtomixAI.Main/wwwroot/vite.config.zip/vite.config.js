import { defineConfig } from 'vite'

export default defineConfig({
  // ЭТОТ БЛОК РЕШАЕТ ПРОБЛЕМУ СО СКРИНШОТА
  define: {
    'process.env': {},
    'process': { env: {} }
  },
  build: {
    outDir: './',
    emptyOutDir: false,
    lib: {
      entry: './main.js',
      formats: ['iife'],
      name: 'app',
      fileName: () => 'bundle.js'
    }
  }
})